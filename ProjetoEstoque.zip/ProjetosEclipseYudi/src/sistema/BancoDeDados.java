package sistema;

import java.util.ArrayList;
import java.util.Scanner;

public class BancoDeDados {
	
	// Simulação com banco de dados
	private static ArrayList<Produto> produtos = new ArrayList<>();
	
	public static void cadastra(Produto p) {
		produtos.add(p);
		System.out.println("\nProduto cadastrado com sucesso!!");
	}
	
	public static void mostrar() {
		if(!produtos.isEmpty()) {
			for(Produto p : produtos) {
				System.out.println("\nCódigo: " + p.getCodigo()
								   + "\nNome Prod. : " + p.getNomeProduto()
								   + "\nPreço: " + p.getPreco()
								   + "\nQtd. : " + p.getQuantidade() + "\n");
			}
		} else {
			System.out.println("\nNão existem produtos cadastrados!");
		}
	}
	
	public static void mostraProduto(int codigo) {
		if(produtos.size() == 0) {
			System.out.println("\nNenhum produto cadastrado!"); 
			return;
		}
		
		for(Produto p : produtos) {
			if(p.getCodigo() == codigo) {
				System.out.println("\nCódigo: " + p.getCodigo()
									+ "\nNome Prod. : " + p.getNomeProduto()
									+ "\nPreço: " + p.getPreco()
									+ "\nQtd. : " + p.getQuantidade()
									+ "\n");
				return;
			}
		}
		
		System.out.println("\nProduto não encontrado!");
	}
	
	public static void delProduto(int codigo) {
		if(produtos.size() == 0) {
			System.out.println("\nNenhum produto cadastrado!");
			return;
		}
		
		for(Produto p: produtos) {
			if(p.getCodigo() == codigo) {
				produtos.remove(p);
				System.out.println("\nProduto deletado com sucesso!");
				return;
			}
		}
		
		System.out.println("\nProduto não encontrado!");
	}
	
	public static void editProduto(int codigo, Scanner sc) {
		
		Produto produtoEncontrado = null;
		
		for(Produto p: produtos) {
			if(p.getCodigo() == codigo) {
				produtoEncontrado = p;
				break;
			}
		}
		
		if(produtoEncontrado == null) {
			System.out.println("Produto não encontrado!");
			return;
		}
		
		System.out.println("\nCódigo: " + produtoEncontrado.getCodigo()
							+ "\nNome Prod. : " + produtoEncontrado.getNomeProduto()
							+ "\nPreço: " + produtoEncontrado.getPreco()
							+ "\nQtd. : " + produtoEncontrado.getQuantidade()
							+ "\n");
		
		System.out.println("\n======== Alterar dados ========");
		System.out.print("Novo Nome: ");
		produtoEncontrado.setNomeProduto(sc.nextLine());
		
		System.out.print("Novo Preco: ");
		produtoEncontrado.setPreco(Double.parseDouble(sc.nextLine()));
		
		System.out.print("Novo Qtd. : ");
		produtoEncontrado.setQuantidade(Integer.parseInt(sc.nextLine()));
		
		System.out.println("\nAlterado com sucesso!");
	}
}
